ALIVE BY MOONLIGHT!
by Studio Pond

Done:
Basic Game
Updater

To Do:
Pallet alternatives
Lockers
Chests
Hatch
Walled structures with vaultable ledges (included with better map generation)
Hero repairs becon
Proper menus
Proper results screen
Choice of heros with different powers
Tutorial
Items (healthkits, becon damaging item, etc)
Perks
AI control for demons or killers
Multiplayer
Sound
Visibility limiter
Auras alternative
Blood/scratch marks alternative
Player points
